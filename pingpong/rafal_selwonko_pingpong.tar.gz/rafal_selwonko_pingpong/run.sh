#!/bin/bash
sbatch -n 2 pingpong.sh
